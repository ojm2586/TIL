package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException; // SQL 예외처리
import java.sql.Statement;

import vo.MemberVO;

public class JDBCTest {
	Connection connection = null;
	Statement statement = null; // 인터페이스는 객체를 생성할 수 없기 때문에 new를 사용할 수 없다.
	String query = "";
	PreparedStatement preparedStatement;
	String driver = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String username = "dev";
	String password = "1111";

	public static void main(String[] args) {

		JDBCTest jdt = new JDBCTest();
		jdt.insert();
// 		JDBC ; Java DataBase Connectivity
// 		자바 어플리케이션과 데이터베이스를 연결하는 라이브러리
// 		자바 프로그램에서 DB에 접근하기 위해 사용

//		1단계 - sql 관련 패키지 import
//		2단계 - JDBC 드라이버 로드
// 	 	3단계 - Connection 객체 생성
//      4단계 - Statement/PreparedSatement 객체 생성
//		5단계 - 쿼리실행
// 		6단계 - 필요 시 ResultSet 객체 생성 사용
//		7단계 - 모든 객체를 닫고 DB 연결 종료
	}

	public void insert() {
		MemberVO mvo = new MemberVO();
		mvo.setMid("Admin");
		mvo.setMname("관리자");
		mvo.setAge(20);
		mvo.setPhone("010-1234-5678");

		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
			statement = connection.createStatement();

			// query = "INSERT INTO t_member VALUES("+ mvo.getMid() + mvo.getMname() +
			// mvo.getAge() + mvo.getPhone() + "'SYSDATE')";
			query = "INSERT INTO t_member VALUES(?,?,?,?,SYSDATE)";

			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, mvo.getMid());
			preparedStatement.setString(2, mvo.getMname());
			preparedStatement.setInt(3, mvo.getAge());
			preparedStatement.setString(4, mvo.getPhone()); // 파라미터,변수

			// 회원추가 쿼리 실행
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				System.out.println("INSERT ok");
			} else {
				System.out.println("INSERT FIAL");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				// statement 및 connection 객체가 null이 아닌 경우에만 각각 닫기 처리
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}// end insert

	public void update() {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
			statement = connection.createStatement();

			query = "UPDATE t_member SET mname = 'LEE' WHERE mid = 'id'";

			// 회원추가 쿼리 실행
			int result = statement.executeUpdate(query);
			if (result != 0) {
				System.out.println("INSERT ok");
			} else {
				System.out.println("INSERT FIAL");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				// statement 및 connection 객체가 null이 아닌 경우에만 각각 닫기 처리
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}// end update

	public void delete() {
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
			statement = connection.createStatement();

			query = "DELETE t_member WHERE mname = 'LEE'";

			// 회원추가 쿼리 실행
			int result = statement.executeUpdate(query);
			if (result != 0) {
				System.out.println("DELETE ok");
			} else {
				System.out.println("DELETE FIAL");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				// statement 및 connection 객체가 null이 아닌 경우에만 각각 닫기 처리
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}// end delete

	public void select() {
	}// end select

	public void selectAll() {
	}// end selectAll

}
