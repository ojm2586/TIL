package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.DBConn;
import vo.MemberVO;
import main.MemberMain;

public class MemberDAO {
	private String query;
	private Statement stm;
	private PreparedStatement pstm;
	private Connection con;
	private ResultSet rs; // SELECT 쿼리를 실행할 결과를 저장

	// 회원조회 - 매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장하여 반환
	// 반환하는 select()메서드(접근제한X)
//	1. 쿼리문
//	2. 겟커넥션 받아오기
//	3. id에 해당할 바인딩
//	4.실행
//	excute.query
	
	public MemberVO select(String mid) {
		MemberVO mvo;
		mvo = null;
		try {
			query = "SELECT * FROM t_member WHERE mid=?";
			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, mid);

			rs = pstm.executeQuery();

			if (rs.next() == true) { // 조회된 레코드가 있다면
				mvo = new MemberVO();// MemberVO 객체를 생성하여
				mvo.setMid(rs.getString("mid"));// 해당 레코드 값을 저장
				mvo.setMname(rs.getString("mname"));
				mvo.setAge(rs.getInt("age"));
				mvo.setPhone(rs.getString("phone"));
				mvo.setRegDate(rs.getDate("reg_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm, rs);

		}

		return mvo;
	}
	
	public int login(String mid, String phone) {
		String adminID = mid;
		String adminPW = phone;
		MemberVO mvo;
		mvo = null;
		try {
			query = "SELECT mid,phone FROM t_member WHERE mid=? AND phone =?";
			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, mid);
			pstm.setString(2, phone);

			rs = pstm.executeQuery();

			if(rs.next()==true){ 
				if(adminID.equals("ADMIN") && adminPW.equals("1111")) { return 2; }
				else { return 1;}
				} else { return 0; }
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm, rs);

		}

		return 0;
	}

	// 회원가입
	public boolean insert(MemberVO mvo) {

		try {
			// insert 쿼리문
			query = "INSERT INTO t_member VALUES(?,?,?,?,SYSDATE)";

			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, mvo.getMid());
			pstm.setString(2, mvo.getMname());
			pstm.setInt(3, mvo.getAge());
			pstm.setString(4, mvo.getPhone());

			int result = pstm.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		// 매개변수로 넘겨받은 데이터를 t_member 테이블에 저장
		// insert 쿼리문
		return false;// 정상적으로 회원가입 성공 시 true 반환
						// 그렇지 않으면 false 반환
	}// insert END

	public boolean update(MemberVO mvo) {
		// 매개변수로 넘겨받은 데이터를 t_member 테이블에 뱐경
		// update 쿼리문
		try {
			// insert 쿼리문
			query = "UPDATE t_member SET age = ?,phone = ? WHERE mid =?";

			pstm = DBConn.getConnection().prepareStatement(query);

			pstm.setInt(1, mvo.getAge());
			pstm.setString(2, mvo.getPhone());
			pstm.setString(3, mvo.getMid());

			int result = pstm.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		return false;// 정상적으로 회원가입 성공 시 true 반환
						// 그렇지 않으면 false 반환
	}// update END

	public boolean delete(String mid) {
		// 매개변수로 넘겨받은 데이터를 삭제
		// delete 쿼리문
		try {
			// insert 쿼리문
			query = "DELETE FROM t_member WHERE mid=?";

			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, mid);

			int result = pstm.executeUpdate();

			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}
		return false;

		// 정상적으로 삭제 성공 시 true 반환
		// 그렇지 않으면 false 반환
	}// delete END

	public List<MemberVO> select() {
		// 회원목록 - 매개변수 : X, 접근제한 : X, 반환타입 : MemberVO를 저장한 List
		// 기능 : t_member 테이블의 전체 데이터를 조회하여 List에 저장한 후 반환

		// 회원조회 - 매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장하여 반환하는 select()메서드
		// (접근제한X)
		List<MemberVO> mvoList = new ArrayList<>(); // new를 하면 null이 아님
		MemberVO mvo;
		mvo = null;
		try {
			query = "SELECT * FROM t_member";
			pstm = DBConn.getConnection().prepareStatement(query);
			// pstm.setString(1, mid); < ?,? 등 매개변수가 없어서 지운다.

			rs = pstm.executeQuery();

			while (rs.next() == true) { // 조회된 레코드들이 있다면 ( 기존 if > while )
				mvo = new MemberVO();// MemberVO 객체를 생성하여
				mvo.setMid(rs.getString("mid"));// 해당 레코드 값을 저장한 후
				mvo.setMname(rs.getString("mname"));
				mvo.setAge(rs.getInt("age"));
				mvo.setPhone(rs.getString("phone"));
				mvo.setRegDate(rs.getDate("reg_date"));

				mvoList.add(mvo);// List 객체에 추가
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		return mvoList;
	}// selecAll END

	public void connectionClose() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
