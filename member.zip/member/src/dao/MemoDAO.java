package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import main.MemberMain;
import util.DBConn;
import vo.MemoVO;


public class MemoDAO {
	
	private String query;
	private Statement stm;
	private PreparedStatement pstm;
	private Connection con;
	private ResultSet rs; // SELECT 쿼리를 실행할 결과를 저장

	// 회원조회 - 매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장하여 반환
	// 반환하는 select()메서드(접근제한X)
//	1. 쿼리문
//	2. 겟커넥션 받아오기
//	3. id에 해당할 바인딩
//	4.실행
//	excute.query
	
	public MemoVO select(int mno) {
		MemoVO mevo;
		mevo = null;
		try {
			query = "SELECT mno,mtitle,memo,reg_date FROM t_memo WHERE mno = ?";
			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setInt(1,mevo.getMno());

			rs = pstm.executeQuery();

			if (rs.next() == true) { // 조회된 레코드가 있다면
				mevo = new MemoVO();// MemoVO 객체를 생성하여
				mevo.setMno(rs.getInt("mno"));
				mevo.setMid(rs.getString("mid"));// 해당 레코드 값을 저장
				mevo.setMtitle(rs.getString("mtitle"));
				mevo.setMemo(rs.getString("memo"));
				mevo.setRegDate(rs.getDate("reg_date"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm, rs);

		}

		return mevo;
	}

	// 회원가입
	public boolean insert(MemoVO mevo) {

		try {
			// insert 쿼리문
			query = "INSERT INTO t_memo(mno,mid,mtitle,memo,reg_date) VALUES(MEMO_SEQ.NEXTVAL,?, ?, ?, SYSDATE)";

			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, MemberMain.id);
			pstm.setString(2, mevo.getMtitle());
			pstm.setString(3, mevo.getMemo());

			int result = pstm.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		// 매개변수로 넘겨받은 데이터를 t_memo 테이블에 저장
		// insert 쿼리문
		return false;// 정상적으로 회원가입 성공 시 true 반환
						// 그렇지 않으면 false 반환
	}// insert END

	public boolean update(MemoVO mevo) {
		// 매개변수로 넘겨받은 데이터를 t_memo 테이블에 뱐경
		// update 쿼리문
		try {
			// insert 쿼리문
			query = "UPDATE t_memo SET memo = ? WHERE mno =?";

			pstm = DBConn.getConnection().prepareStatement(query);

			pstm.setString(1, mevo.getMid());
			pstm.setString(2, mevo.getMemo());
			pstm.setInt(3, mevo.getMno());

			int result = pstm.executeUpdate();
			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		return false;// 정상적으로 회원가입 성공 시 true 반환
						// 그렇지 않으면 false 반환
	}// update END

	public boolean delete(String mid) {
		// 매개변수로 넘겨받은 데이터를 삭제
		// delete 쿼리문
		try {
			// insert 쿼리문
			query = "DELETE FROM t_memo WHERE mid=?";

			pstm = DBConn.getConnection().prepareStatement(query);
			pstm.setString(1, mid);

			int result = pstm.executeUpdate();

			if (result != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}
		return false;

		// 정상적으로 삭제 성공 시 true 반환
		// 그렇지 않으면 false 반환
	}// delete END

	public List<MemoVO> select() {
		// 회원목록 - 매개변수 : X, 접근제한 : X, 반환타입 : MemoVO를 저장한 List
		// 기능 : t_memo 테이블의 전체 데이터를 조회하여 List에 저장한 후 반환

		// 회원조회 - 매개변수로 아이디를 넘겨받아 해당 레코드를 객체에 저장하여 반환하는 select()메서드
		// (접근제한X)
		List<MemoVO> mevoList = new ArrayList<>(); // new를 하면 null이 아님
		MemoVO mevo;
		mevo = null;
		try {
			query = "SELECT * FROM t_memo";
			pstm = DBConn.getConnection().prepareStatement(query);
			// pstm.setString(1, mid); < ?,? 등 매개변수가 없어서 지운다.

			rs = pstm.executeQuery();

			while (rs.next() == true) { // 조회된 레코드들이 있다면 ( 기존 if > while )
				mevo = new MemoVO();// MemoVO 객체를 생성하여
				mevo.setMno(rs.getInt("mno"));
				mevo.setMid(rs.getString("mid"));// 해당 레코드 값을 저장한 후
				mevo.setMemo(rs.getString("memo"));
				mevo.setRegDate(rs.getDate("reg_date"));

				mevoList.add(mevo);// List 객체에 추가
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstm);
		}

		return mevoList;
	}// selecAll END

	public void connectionClose() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
