package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import vo.MemoVO;
import vo.MemberVO;

public class DBConn {
	private static Connection con;
	private static Statement stm;
	private static PreparedStatement pstm;
	private static ResultSet rs;

	private void DBConn() {
	} // 1.외부에서 접근할 수 없는 기본생성자 생성

	public static Connection getConnection() {
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String username = "dev";
		String password = "1111";
		String query = "";
		MemoVO mevo = new MemoVO();
		MemberVO mvo = new MemberVO();

		if (con == null) { // 2.Connection 객체가
			try {
				Class.forName(driver);
				con = DriverManager.getConnection(url, username, password);
				stm = con.createStatement();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return con;
	}

	public static void close(Statement stm) {
		try {
			if (stm != null)
				stm.close();
		}

		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(PreparedStatement pstm) {
		try {
			if (pstm != null)
				pstm.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(PreparedStatement pstm, ResultSet rs) {
		try {
			if (rs != null) rs.close();
			if (pstm != null) pstm.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close() {
		try {
			if(con!=null) con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
