package main;

import java.util.List;
import java.util.Scanner;

import dao.MemoDAO;
import util.DBConn;
import vo.MemoVO;
import main.MemberMain;

public class MemoMain {
	private Scanner scanner; // 다른 메소드에서도 사용해야하기 때문에 멤버 필드로 빼주는게 좋음 // 멤버 필드로 선언
	private int scNum; // scanner int값 저장 변수
	private MemoVO mevo;
	private MemoDAO medao; // static 이 아니므로 객체 오브젝트 인스턴스 참조변수가 필요함
	String mid = "";
	int loop = 0;


	// if static이 있다면 클래스이름.메소드로 호출가능
	// 생성자 : 최초 실행시 한번 초기화
	public MemoMain() {
		super();
		scanner = new Scanner(System.in); // (키보드입력)멤버 필드 초기화
		scNum = 0;
		mevo = new MemoVO();
		medao = new MemoDAO();

	}

	public void memoMenu() {
		
		System.out.println(MemberMain.id);
		System.out.println("------------------------------------------");
		System.out.println("    MEMBER MANAGEMENT SYSTEM MAIN   ");
		System.out.println("------------------------------------------");
		System.out.println("1. 메모 작성 ");//INSERT
		System.out.println("2. 선택 조회"); //SELECT
		System.out.println("3. 목록 조회"); //SELECT ALL
		System.out.println("4. 메모 수정"); //UPDATE
		System.out.println("5. 메모 삭제"); //DELETE
		System.out.println("6. 로그아웃");
		System.out.print(">> 선택 : ");
		scNum = scanner.nextInt();
		
		MemberMain memberMain = new MemberMain();
		
		switch (scNum) {
		case 1:
			memoInsert();
			break;

		case 2:
			memoInfo();
			break;

		case 3:

			break;
		
		case 4:
			
			break;
			
		case 5:
			System.out.println("[알림] 로그아웃이 완료 되었습니다.");
			memberMain.login();
			break;

		default:
			System.out.println("[오류] 잘못 입력하셨습니다. 1~4번 중 하나를 입력해주세요");
			memoMenu();
			break;
		}
	}
	
		
	

	public void memoInsert() {
		// 메모 작성 게시판 구현

		System.out.println("------------------------------------------");
		System.out.println("    MEMO INSERT    ");
		System.out.println("------------------------------------------");
		System.out.print("제목 : ");
		mevo.setMtitle(scanner.next());
		System.out.print("메모 내용 : ");
		mevo.setMemo(scanner.next());
		
		if (medao.insert(mevo) != false) {
			System.out.println(">>>[알림] 메모 완료");
			memoMenu();
		} else {

			System.out.println(">>>[오류]  메모 실패");
			memoMenu();

		}

	} // 회원 가입

//	public void list() {
//		int listCount;
//
//		System.out.println("------------------------------------------");
//		System.out.println("    MEMBER LIST    ");
//		System.out.println("------------------------------------------");
//		List<MemoVO> mevoList = medao.select();// 2.입력 받은 아이디 DAO Select메서드에 매개변수로 넣는다.
//		listCount = mevoList.size() - 1;
//		// 3. 반환 되는 멤버 VO 반환받기
//		if (mevoList.size() > 0) { // 등록된 게시물이 있으면 화면에 표시
//			System.out.println("아이디 | 이름 | 나이 | 전화번호 | 가입일자");
//			while (listCount + 1 != 0) {
//
//				System.out.println(mevoList.get(listCount).getMid() + "\t" + mevoList.get(listCount).getMname() + "\t"
//						+ mevoList.get(listCount).getAge() + "\t" + mevoList.get(listCount).getPhone() + "\t"
//						+ mevoList.get(listCount).getRegDate() + "\t"); // 4.화면 출력
//
//				listCount--;
//			}
//
//			memoMenu();
//		} else {
//			System.out.println("등록된 회원이 없습니다.");
//		}
//
//	} // 회원 목록

	public void memoInfo() { // 회원 조회
		System.out.println("------------------------------------------");
		System.out.println("    MEMBER INFO    ");
		System.out.println("------------------------------------------");
		System.out.print(" 일련번호 : ");
		int mno = scanner.nextInt(); // 1. 조회할 mno 일련번호 입력 받기

		mevo = medao.select(mno);

		// 2.입력 받은 아이디 DAO Select메서드에 매개변수로 넣는다.
		// 3. 반환 되는 멤버 VO 반환받기
		if (mevo != null) {
		
			System.out.println("일련번호 : " + mevo.getMno()); // 4.화면 출력
			System.out.println("작성자 : " + mevo.getMid());
			System.out.println("제목 : " + mevo.getMtitle());
			System.out.println("메모내용 : " + mevo.getMemo());
			System.out.println("작성일자 : " + mevo.getRegDate());
			System.out.println("--------------------------------------");
			System.out.println("1. 메모 수정     2. 메모 삭제     3. 메인 메뉴");
			scNum = scanner.nextInt();
		} else {
			memoMenu();
		}

		switch (scNum) {
		case 1:
			modify();
			break;
		case 2:
			remove();
			break;
		case 3:
			memoMenu();
			break;
		default:
			System.out.println("[오류] 1~3번 중 하나를 입력해주세요");
			memoInfo();
			break;

		}
	}

	public void modify() {
//
//		System.out.print(" 수정 나이 : ");
//		mevo.setAge(scanner.nextInt());
//		System.out.print(" 수정 전화번호 : ");
//		mevo.setPhone(scanner.next());
//
//		System.out.println("정말로 수정하시겠습니까? Y/N");
//		String input = scanner.next();
//
//		if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("y")) {
//			if (medao.update(mevo) != false) {
//				System.out.println(">>>[알림]  수정 성공. 메뉴로 돌아갑니다");
//				memoMenu();
//			} else {
//				System.out.println(">>>[오류]  수정 실패. 메뉴로 돌아갑니다");
//				memoMenu();
//			}
//		} else if (input.equalsIgnoreCase("N") || input.equalsIgnoreCase("n")) {
//			System.out.println(">>[알림] 취소 되었습니다. 메뉴로 돌아갑니다");
//			memoMenu();
//		} else {
//			System.out.println("[오류] Y 또는 N을 입력해주세요. ");
//			modify();
//		}
//
	}// 회원 수정 END

	public void remove() {
//		mid = mevo.getMid();
//		System.out.println("정말로 삭제하시겠습니까? Y/N");
//		String input = scanner.next();
//
//		if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("y")) {
//			if (medao.delete(mid) != false) {
//				System.out.print(">>>[알림] 삭제 완료");
//				memoMenu();
//			} else {
//				System.out.print(">>>[오류] 삭제 실패");
//				memoMenu();
//			}
//		} else if (input.equalsIgnoreCase("N") || input.equalsIgnoreCase("n")) {
//			System.out.println(">>[알림] 메뉴로 돌아갑니다");
//			memoMenu();
//		} else {
//			System.out.println("[오류] Y 또는 N을 입력해주세요.");
//			remove();
//		}
	}// 회원 삭제

}// 클래스 END
