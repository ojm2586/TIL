package main;

import java.util.List;
import java.util.Scanner;
import dao.MemberDAO;
import util.DBConn;
import vo.MemberVO;
import main.MemoMain;

public class MemberMain {
	private Scanner scanner; // 다른 메소드에서도 사용해야하기 때문에 멤버 필드로 빼주는게 좋음 // 멤버 필드로 선언
	private int scNum; // scanner int값 저장 변수
	private MemberVO mvo;
	private MemberDAO mdao; // static 이 아니므로 객체 오브젝트 인스턴스 참조변수가 필요함
	String mid = "";
	int loop = 0;
	MemoMain memoMain = new MemoMain();
	public static String id; // 로그인 중인 


	// if static이 있다면 클래스이름.메소드로 호출가능
	// 생성자 : 최초 실행시 한번 초기화
	public MemberMain() {
		super();
		scanner = new Scanner(System.in); // (키보드입력)멤버 필드 초기화
		scNum = 0;
		mvo = new MemberVO();
		mdao = new MemberDAO();


	}

	public static void main(String[] args) {

		// MemberMain memoMain = new MemberMain(); 메인 메소드는 static 이 있지만 menu 메소드는 없기에 객체 인스턴스를
		// 생성해줘야함
		// memoMain.adminMenu();
		new MemberMain().loginadminMenu(); // 한번만 실행해도 되면 이것도 가능
	}

	public void loginadminMenu() {
		System.out.println("------------------------------------------");
		System.out.println("    MEMBER MANAGEMENT SYSTEM    ");
		System.out.println("------------------------------------------");
		System.out.println("1. 로그인");
		System.out.println("2. 회원가입");
		System.out.println("3. 종료");
		System.out.print(">> 선택 : ");
		scNum = scanner.nextInt();

		switch (scNum) {
		case 1:
			login();

			break;

		case 2:
			join();
			break;

		case 3:
			System.out.println("------------------------------------------");
			System.out.println("    SYSTEM END   ");
			System.out.println("------------------------------------------");
			scanner.close(); // 스캐너 종료처리
			DBConn.close();
			System.exit(0);


		default:
			System.out.println("[오류] 잘못 입력하셨습니다. 1~4번 중 하나를 입력해주세요");
			adminMenu();
			break;
		}

	}
	
	public void adminMenu() {
		System.out.println("------------------------------------------");
		System.out.println("    MEMBER MANAGEMENT SYSTEM    ");
		System.out.println("------------------------------------------");
		System.out.println("1. 회원 추가");
		System.out.println("2. 회원 목록");
		System.out.println("3. 회원 조회");
		System.out.println("4. 로그아웃");	
		System.out.println("5. 종료 ");
		System.out.print(">> 선택 : ");
		scNum = scanner.nextInt();

		switch (scNum) {
		case 1:
			join();
			break;

		case 2:
			list();
			break;

		case 3:
			info();
			break;
			
		case 4:
			login();
			break;

		case 5:
			System.out.println("------------------------------------------");
			System.out.println("    SYSTEM END   ");
			System.out.println("------------------------------------------");
			scanner.close(); // 스캐너 종료처리
			DBConn.close();
			System.exit(0);
			break;

		default:
			System.out.println("[오류] 잘못 입력하셨습니다. 1~4번 중 하나를 입력해주세요");
			adminMenu();
			break;
		}

	}


	public void join() {
		// 회원 가입에 필요한 정보를 입력받아서
		// 객체에 저장한 후 DAO 클래스의 메서드로 전달

		System.out.println("------------------------------------------");
		System.out.println("    MEMBER JOIN    ");
		System.out.println("------------------------------------------");
		System.out.print(" 아이디 : ");
		mvo.setMid(scanner.next()); // 키보드를 입력받고 매개변수로 바로 전달한다.
		System.out.print(" 이름 : ");
		mvo.setMname(scanner.next());
		System.out.print(" 나이 : ");
		mvo.setAge(scanner.nextInt());
		System.out.print(" 전화번호 : ");
		mvo.setPhone(scanner.next());

		if (mdao.insert(mvo) != false) {
			System.out.println(">>>[알림] 회원가입 성공");
			login();
		} else {

			System.out.println(">>>[오류]  회원가입 실패");
			adminMenu();

		}

	} // 회원 가입

	public void login() {
		int listCount;

		System.out.println("------------------------------------------");
		System.out.println("    MEMBER Login    ");
		System.out.println("------------------------------------------");
		System.out.print("아이디 : ");
		String mid = scanner.next();
		System.out.print("비밀번호 : ");
		String phone = scanner.next();
		
		int loginResult = mdao.login(mid,phone);// 2.입력 받은 아이디 DAO Select메서드에 매개변수로 넣는다.
		// 3. 반환 되는 멤버 VO 반환받기

		switch(loginResult) { 
		
		case 0:
			System.out.println("[오류] 아이디 또는 비밀번호가 맞지 않거나 등록된 회원이 없습니다.");
			loginadminMenu(); // 다시 로그인 메뉴로
			break;
		
		case 1:
			id = mid;
			System.out.println(id);
			System.out.println("[알림] 로그인에 성공하였습니다."); 
			memoMain.memoMenu(); // 메모메인 메소드 호출
			break;
		case 2:
			id = mid;
			System.out.println(">>> 관리자 계정으로 로그인 하였습니다 <<<");
			adminMenu(); //관리자메뉴 호출
			break;
			
		default :
			break;
		}
		
	} // 회원 목록
	
	public void list() {
		int listCount;

		System.out.println("------------------------------------------");
		System.out.println("    MEMBER LIST    ");
		System.out.println("------------------------------------------");
		List<MemberVO> mvoList = mdao.select();// 2.입력 받은 아이디 DAO Select메서드에 매개변수로 넣는다.
		listCount = mvoList.size() - 1;
		// 3. 반환 되는 멤버 VO 반환받기
		if (mvoList.size() > 0) { // 등록된 게시물이 있으면 화면에 표시
			System.out.println("아이디 | 이름 | 나이 | 전화번호 | 가입일자");
			while (listCount + 1 != 0) {

				System.out.println(mvoList.get(listCount).getMid() + "\t" + mvoList.get(listCount).getMname() + "\t"
						+ mvoList.get(listCount).getAge() + "\t" + mvoList.get(listCount).getPhone() + "\t"
						+ mvoList.get(listCount).getRegDate() + "\t"); // 4.화면 출력

				listCount--;
			}

			adminMenu();
		} else {
			System.out.println("등록된 회원이 없습니다.");
		}

	} // 회원 목록

	public void info() { // 회원 조회
		System.out.println("------------------------------------------");
		System.out.println("    MEMBER INFO    ");
		System.out.println("------------------------------------------");
		System.out.print(" 조회 할 아이디 : ");
		String mid = scanner.next(); // 1. 조회할 아이디 입력 받기

		mvo = mdao.select(mid);

		// 2.입력 받은 아이디 DAO Select메서드에 매개변수로 넣는다.
		// 3. 반환 되는 멤버 VO 반환받기
		if (mvo != null) {
			System.out.println("이름 : " + mvo.getMid()); // 4.화면 출력
			System.out.println("나이 : " + mvo.getAge());
			System.out.println("전화번호 : " + mvo.getPhone());
			System.out.println("가입일자 : " + mvo.getRegDate());
			System.out.println("--------------------------------------");
			System.out.println("1 회원 수정     2 회원 삭제     3 메인 메뉴");
			scNum = scanner.nextInt();
		} else {
			System.out.println("해당 아이디가 존재하지 않습니다");
			adminMenu();
		}

		switch (scNum) {
		case 1:
			modify();
			break;
		case 2:
			remove();
			break;
		case 3:
			adminMenu();
			break;
		default:
			System.out.println("[오류] 1~3번 중 하나를 입력해주세요");
			info();
			break;

		}
	}

	public void modify() {

		System.out.print(" 수정 나이 : ");
		mvo.setAge(scanner.nextInt());
		System.out.print(" 수정 전화번호 : ");
		mvo.setPhone(scanner.next());

		System.out.println("정말로 수정하시겠습니까? Y/N");
		String input = scanner.next();

		if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("y")) {
			if (mdao.update(mvo) != false) {
				System.out.println(">>>[알림]  수정 성공. 메뉴로 돌아갑니다");
				adminMenu();
			} else {
				System.out.println(">>>[오류]  수정 실패. 메뉴로 돌아갑니다");
				adminMenu();
			}
		} else if (input.equalsIgnoreCase("N") || input.equalsIgnoreCase("n")) {
			System.out.println(">>[알림] 취소 되었습니다. 메뉴로 돌아갑니다");
			adminMenu();
		} else {
			System.out.println("[오류] Y 또는 N을 입력해주세요. ");
			modify();
		}

	}// 회원 수정 END

	public void remove() {
		mid = mvo.getMid();
		System.out.println("정말로 삭제하시겠습니까? Y/N");
		String input = scanner.next();

		if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("y")) {
			if (mdao.delete(mid) != false) {
				System.out.print(">>>[알림] 삭제 완료");
				adminMenu();
			} else {
				System.out.print(">>>[오류] 삭제 실패");
				adminMenu();
			}
		} else if (input.equalsIgnoreCase("N") || input.equalsIgnoreCase("n")) {
			System.out.println(">>[알림] 메뉴로 돌아갑니다");
			adminMenu();
		} else {
			System.out.println("[오류] Y 또는 N을 입력해주세요.");
			remove();
		}
	}// 회원 삭제

}// 클래스 END
